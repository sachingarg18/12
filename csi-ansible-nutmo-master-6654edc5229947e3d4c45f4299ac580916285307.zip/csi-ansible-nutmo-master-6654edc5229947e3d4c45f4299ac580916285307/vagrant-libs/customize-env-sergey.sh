# Sergey's customization and convenience settings for bash inside Vagrant
# The file is to be sourced into the active bash session

alias d="ls -AlF"

echo "Customizations have been applied successfully."
